import Vue from 'vue'
import App from './App.vue'
import VueRouter from 'vue-router'  // Add this
import router from './router'       // Add this

Vue.use(VueRouter);         // Add this

// only import the icons you use to reduce bundle size
import 'vue-awesome/icons/map-marker'
import 'vue-awesome/icons/angle-down'
import 'vue-awesome/icons/angle-up'
import Icon from 'vue-awesome/components/Icon'



// globally (in your main .js file)
Vue.component('icon', Icon);

window.$ = window.jQuery = require('jquery');

require('../node_modules/bootstrap/scss/bootstrap.scss');

require('../node_modules/bootstrap/dist/js/bootstrap.min');

require('./assets/css/main_style.scss');

Vue.config.productionTip = false;

new Vue({
  el: '#app',
  router,                           // Add this
  render: h => h(App)
})
