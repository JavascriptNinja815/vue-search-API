const DAYS_WEEK = [
  {
    name: 'Monday',
    id: '',
  },
  {
    name: 'Tuesday',
    id: '',
  },
  {
    name: 'Wednesday',
    id: '',
  },
  {
    name: 'Thrusday',
    id: '',
  },
  {
    name: 'Friday',
    id: '',
  },
  {
    name: 'Saturday',
    id: '',
  },
  {
    name: 'Sunday',
    id: '',
  },
]

export const CATEGORIES = [
  {
    name: 'Substance Abuse Services',
    id: 'sa',
    filters: [
      {
        name: 'Type of Care',
        id: 'sa_type_of_care',
        options: [
          {
            name: 'Substance abuse treatment',
            id: '',
          },
          {
            name: 'Detoxification',
            id: '',
          },
          {
            name: 'Transitional housing or halfway house',
            id: '',
          },
          {
            name: 'Accepts clients on opioid medication',
            id: '',
          },
          {
            name: 'Prescribes/administer buprenorphine and/or naltrexone',
            id: '',
          },
          {
            name: 'SAMHSA-certified Opioid Treatment Program',
            id: '',
          },
        ],
      },
      {
        name: 'Service Setting',
        id: 'sa_service_setting',
        options: [
          {
            name: 'Hospital inpatient',
            id: '',
          },
          {
            name: 'Residential',
            id: '',
          },
          {
            name: 'Outpatient',
            id: '',
          },
          {
            name: 'Short-term residential',
            id: '',
          },
          {
            name: 'Long-term residential',
            id: '',
          },
          {
            name: 'Residential detoxification',
            id: '',
          },
          {
            name: 'Outpatient detoxification',
            id: '',
          },
          {
            name: 'Outpatient methadone/buprenorphine or naltrexone',
            id: '',
          },
          {
            name: 'Intensive outpatient treatment',
            id: '',
          },
          {
            name: 'Regular outpatient treatment',
            id: '',
          },
          {
            name: 'Hospital inpatient detoxification',
            id: '',
          },
          {
            name: 'Hospital inpatient treatment',
            id: '',
          },
        ],
      },
      {
        name: 'Payment/Insurance Accepted',
        id: 'sa_payment_or_insurance_accepted',
        options: [
          {
            name: 'No payment accepted',
            id: '',
          },
          {
            name: 'Cash or self-payment',
            id: '',
          },
          {
            name: 'Medicaid',
            id: '',
          },
          {
            name: 'Medicare',
            id: '',
          },
          {
            name: 'State financed health insurance plan other than Medicaid',
            id: '',
          },
          {
            name: 'Private health insurance',
            id: '',
          },
          {
            name: 'Military insurance',
            id: '',
          },
          {
            name: 'IHS/Tribal/Urban (ITU) funds',
            id: '',
          },
        ],
      },
      {
        name: 'Payment Assistance Available',
        id: 'sa_payment_assistance_available',
        options: [
          {
            name: 'Sliding fee scale (fee is based on income and other factors)',
            id: '',
          },
          {
            name: 'Payment assistance (check with facility for details)',
            id: '',
          },

        ],
      },

      {
        name: 'Special Programs/Groups Offered',
        id: 'sa_special_programs_and_groups_offered',
        options: [
          {
            name: 'Persons with co-occurring mental and substance abuse disorders',
            id: '',
          },
          {
            name: 'Lesbian, gay, bisexual, or transgender (LGBT) clients',
            id: '',
          },
          {
            name: 'Veterans',
            id: '',
          },
          {
            name: 'Active duty military',
            id: '',
          },
          {
            name: 'Military families',
            id: '',
          },
          {
            name: 'Clients referred from the court/judicial system',
            id: '',
          },
          {
            name: 'Seniors or older adults',
            id: '',
          },
          {
            name: 'Adolescents',
            id: '',
          },
          {
            name: 'Pregnant/postpartum women',
            id: '',
          },
          {
            name: 'Adult women',
            id: '',
          },
          {
            name: 'Adult men',
            id: '',
          },
          {
            name: 'Persons with HIV or AIDS',
            id: '',
          },
          {
            name: 'Persons who have experienced trauma',
            id: '',
          },
          {
            name: 'Persons who have experienced sexual abuse',
            id: '',
          },
          {
            name: 'Persons who have experienced intimate partner violence, domestic violence',
            id: '',
          },
          {
            name: 'Transitional age young adults',
            id: '',
          },

        ],
      },
      {
        name: 'Ancillary Services',
        id: 'sa_ancillary_services',
        options: [
          {
            name: 'Treatment for gambling disorder',
            id: '',
          },
          {
            name: 'Treatment for internet use disorder',
            id: '',
          },

        ],
      },
      {
        name: 'Age Groups Accepted',
        id: 'sa_age_groups_accepted',
        options: [
          {
            name: 'Children/adolescents',
            id: '',
          },
          {
            name: 'Young adults',
            id: '',
          },
          {
            name: 'Adults',
            id: '',
          },

        ],
      },
      {
        name: 'Gender Accepted',
        id: '',
        options: [
          {
            name: 'Female',
            id: '',
          },
          {
            name: 'Male',
            id: '',
          },

        ],
      },
      {
        name: 'Exclusive Services',
        id: 'sa_exclusive_services',
        options: [
          {
            name: 'Methadone and buprenorphine clients only',
            id: '',
          },
          {
            name: 'Methadone clients only',
            id: '',
          },
          {
            name: 'DUI/DWI clients',
            id: '',
          },
          {
            name: 'Serve only DWI clients',
            id: '',
          },

        ],
      },
      {
        name: 'Language Services',
        id: 'sa_language_services',
        options: [
          {
            name: 'Services for the deaf and hard of hearing',
            id: '',
          },

        ],
      },
      {
        name: 'Other Languages',
        id: 'sa_other_languages',
        options: [
          {
            name: 'Arabic',
            id: '',
          },
          {
            name: 'Any Chinese Language',
            id: '',
          },
          {
            name: 'Creole',
            id: '',
          },
          {
            name: 'Farsi',
            id: '',
          },
          {
            name: 'French',
            id: '',
          },
          {
            name: 'German',
            id: '',
          },
          {
            name: 'Greek',
            id: '',
          },
          {
            name: 'Hebrew',
            id: '',
          },
          {
            name: 'Hindi',
            id: '',
          },
          {
            name: 'Hmong',
            id: '',
          },
          {
            name: 'Italian',
            id: '',
          },
          {
            name: 'Japanese',
            id: '',
          },
          {
            name: 'Korean',
            id: '',
          },
          {
            name: 'Polish',
            id: '',
          },
          {
            name: 'Portuguese',
            id: '',
          },
          {
            name: 'Russian',
            id: '',
          },
          {
            name: 'Spanish',
            id: '',
          },

        ],
      },

    ]
  },
  {
    name: 'Buprenorphine Physicians',
    id: 'bp',
    filters: [],
  },
  {
    name: 'Mental Health Services',
    id: 'mh',
    filters: [
      {
        name: 'Emergency Mental Health Services',
        id: 'mh_emergency_mental_health_services',
        options: [
          {
            name: 'Crisis intervention team',
            id: '',
          },
          {
            name: 'Psychiatric emergency walk-in services',
            id: '',
          },

        ]
      },
      {
        name: 'Type of Care',
        id: 'mh_type_of_care',
        options: [
          {
            name: 'Mental health treatment',
            id: '',
          },

        ]
      },
      {
        name: 'Service Setting',
        id: 'mh_service_setting',
        options: [
          {
            name: 'Hospital inpatient',
            id: '',
          },
          {
            name: 'Residential',
            id: '',
          },
          {
            name: 'Partial hospitalization/day treatment',
            id: '',
          },
          {
            name: 'Outpatient',
            id: '',
          },

        ],
      },
      {
        name: 'Facility Operation (e.g. Private, Public)',
        id: 'mh_facility_operation',
        options: [
          {
            name: 'U.S. Department of Veterans Affairs',
            id: '',
          },

        ],
      },
      {
        name: 'Payment/Insurance Accepted',
        id: 'mh_payment_or_insurance_accepted',
        options: [

          {
            name: 'Cash or self-payment',
            id: '',
          },
          {
            name: 'Medicaid',
            id: '',
          },
          {
            name: 'Medicare',
            id: '',
          },
          {
            name: 'State financed health insurance plan other than Medicaid',
            id: '',
          },
          {
            name: 'Private health insurance',
            id: '',
          },
          {
            name: 'Military insurance',
            id: '',
          },
          {
            name: 'IHS/Tribal/Urban (ITU) funds',
            id: '',
          },
        ],
      },
      {
        name: 'Payment Assistance Available',
        id: 'mh_payment_assistance_available',
        options: [
          {
            name: 'Sliding fee scale (fee is based on income and other factors)',
            id: '',
          },
          {
            name: 'Payment assistance (check with facility for details)',
            id: '',
          },

        ],
      },
      {
        name: 'Special Programs/Groups Offered',
        id: 'mh_special_programs_and_groups_offered',
        options: [
          {
            name: 'Persons with co-occurring mental and substance abuse disorders',
            id: '',
          },
          {
            name: 'Lesbian, gay, bisexual, or transgender (LGBT) clients',
            id: '',
          },
          {
            name: 'Veterans',
            id: '',
          },
          {
            name: 'Active duty military',
            id: '',
          },
          {
            name: 'Military families',
            id: '',
          },
          {
            name: 'Clients referred from the court/judicial system',
            id: '',
          },
          {
            name: 'Seniors or older adults',
            id: '',
          },
          {
            name: 'Persons with HIV or AIDS',
            id: '',
          },
          {
            name: 'Persons who have experienced trauma',
            id: '',
          },
          {
            name: 'Children with serious emotional disturbance (SED)',
            id: '',
          },
          {
            name: 'Persons with serious mental illness (SMI)',
            id: '',
          },
          {
            name: 'Persons with Alzheimer\'s or dementia',
            id: '',
          },
          {
            name: 'Persons with post-traumatic stress disorder (PTSD)',
            id: '',
          },
          {
            name: 'Persons with traumatic brain injury (TBI)',
            id: '',
          },
          {
            name: 'Transitional age young adults',
            id: '',
          },
          {
            name: 'Persons with eating disorders',
            id: '',
          },

        ],
      },
      {
        name: 'Age Groups Accepted',
        id: 'mh_age_groups_accepted',
        options: [
          {
            name: 'Children/adolescents',
            id: '',
          },
          {
            name: 'Young adults',
            id: '',
          },
          {
            name: 'Adults',
            id: '',
          },
          {
            name: 'Seniors (65 or older)',
            id: '',
          },
        ],
      },
      {
        name: 'Language Services',
        id: 'mh_language_services',
        options: [
          {
            name: 'Services for the deaf and hard of hearing',
            id: '',
          },

        ],
      },
      /* {
         name: 'American Indian or Alaskan Native Languages',
         id: '',
         options: [
           {
             name: 'Hopi',
             id: '',
           },
           {
             name: 'Lakota',
             id: '',
           },
           {
             name: 'Navajo',
             id: '',
           },
           {
             name: 'Ojibwa',
             id: '',
           },
           {
             name: 'Yupik',
             id: '',
           },

         ],
       },*/
      {
        name: 'Other Languages',
        id: 'mh_other_languages',
        options: [
          {
            name: 'Arabic',
            id: '',
          },
          {
            name: 'Any Chinese Language',
            id: '',
          },
          {
            name: 'Creole',
            id: '',
          },
          {
            name: 'Farsi',
            id: '',
          },
          {
            name: 'French',
            id: '',
          },
          {
            name: 'German',
            id: '',
          },
          {
            name: 'Greek',
            id: '',
          },
          {
            name: 'Hebrew',
            id: '',
          },
          {
            name: 'Hindi',
            id: '',
          },
          {
            name: 'Hmong',
            id: '',
          },
          {
            name: 'Italian',
            id: '',
          },
          {
            name: 'Japanese',
            id: '',
          },
          {
            name: 'Korean',
            id: '',
          },
          {
            name: 'Polish',
            id: '',
          },
          {
            name: 'Portuguese',
            id: '',
          },
          {
            name: 'Russian',
            id: '',
          },
          {
            name: 'Spanish',
            id: '',
          },

        ],
      },
    ],
  },
  {
    name: 'Health Care Centers',
    id: 'hc',
    filters: [],
  },
  {
    name: 'Naloxone',
    id: 'nal',
    filters: [
      {
        name: 'Day of the Week',
        id: 'days_of_week',
        options: DAYS_WEEK,
      },
    ],
  },
  {
    name: 'Syringe Exchange Program',
    id: 'sep',
    filters: [
      {
        name: 'Day of the Week',
        id: 'days_of_week',
        filters: DAYS_WEEK,
      },
    ],
  },
  {
    name: 'AA Meetings',
    id: 'sep',
    filters: [
      /*  {
          name: 'Day of the Week',
          id: 'days_of_week',
          options: DAYS_WEEK,
        },*/
      {
        name: 'Who Can Attend',
        id: 'who_can_attend',
        options: [
          {
            name: 'Open to family and friends',
            id: 'is_open_to_family_members_and_friends',
          },
          {
            name: 'Closed',
            id: 'is_open_to_family_members_and_friends',
          },
          {
            name: 'Men Only',
            id: 'is_men_only',
          },
          {
            name: 'Women Only',
            id: 'is_women_only',
          },
          {
            name: 'Newcomer',
            id: 'is_open_to_newcomers',
          },
          {
            name: 'Child-Friendly',
            id: 'is_child_friendly',
          },
          {
            name: 'Young People',
            id: 'is_young_people',
          },
          {
            name: 'Concurrent with Al-Anon',
            id: 'is_al_anon',
          },
          {
            name: 'Concurrent with Alateen',
            id: 'is_alateen',
          },
          {
            name: 'Gay',
            id: 'is_gay',
          },
          {
            name: 'LGBTQ',
            id: 'is_lgbtq',
          },
          {
            name: 'Lesbian',
            id: 'is_lesbian',
          },
          {
            name: 'Transgender',
            id: 'is_transgender',
          },

        ],
      },
      {
        name: 'Wheelchair Accesible',
        id: 'is_wheelchair_accessible',
        options:
          [
            {
              name: 'Wheelchair Access',
              id: 'is_wheelchair_accessible',
            }
          ],

      },
      {
        name: 'Format',
        id: 'format',
        options:
          [
            {
              name: '11th Step Meditation',
              id: 'is_eleven_step',
            },
            {
              name: 'As Bill Sees It',
              id: 'is_asbi',
            },
            {
              name: 'Atheist / Agnostic',
              id: 'is_atheist_or_agnostic',
            },
            {
              name: 'Birthday',
              id: 'is_birthday',
            },
            {
              name: 'Breakfast',
              id: 'is_breakfast',
            },
            {
              name: 'Candlelight',
              id: 'is_candlelight',
            },
            {
              name: 'Daily Reflections',
              id: 'is_daily_reflections',
            },
            {
              name: 'Discussion',
              id: 'is_discussion',
            },
            {
              name: 'Dual Diagnosis',
              id: 'is_dual_diagnosis',
            },
            {
              name: 'Fragance Free',
              id: 'is_fragrance_free',
            },
            {
              name: 'Step Meeting',
              id: 'is_step',
            },
            {
              name: 'Speaker',
              id: 'is_speaker',
            },
            {
              name: 'Literature Study',
              id: 'is_literature_study',
            },
            {
              name: 'Tradition Study',
              id: 'is_tradition',
            },
            {
              name: 'Meditation',
              id: 'is_meditation',
            },
            {
              name: 'Big Book',
              id: 'is_big_book',
            },

            {
              name: 'Grapevine',
              id: 'is_grapevine',
            },
            {
              name: 'Living Sober',
              id: 'is_living_sober',
            },



          ],

      },
      {
        name: 'Cross Talk Permitted',
        id: 'is_cross_talk',
        options:
          [
            {
              name: 'Cross Talk Permitted',
              id: 'is_cross_talk',
            },


          ],

      },
      {
        name: 'Babysitting Available',
        id: 'is_babysitting_available',
        options:
          [
            {
              name: 'Babysitting Available',
              id: 'is_babysitting_available',
            },


          ],

      },
      {
        name: 'Facility Smoking Policy',
        id: 'facility_smoking_policy',
        options:
          [
            {
              name: 'No Smoking',
              id: 'is_smoking_permitted',
            },
            {
              name: 'Smoking Permitted',
              id: 'is_smoking_permitted',
            },
            /*  {
                name: 'Vaping Permitted',
                id: 'is_vaping_permitted',
              },*/
          ],

      },
      {
        name: 'Language',
        id: 'language',
        options: [



          {
            name: 'French',
            id: 'is_french',
          },

          {
            name: 'Italian',
            id: 'is_italian',
          },

          {
            name: 'Korean',
            id: 'is_korean',
          },
          {
            name: 'Native American',
            id: 'is_native_american',
          },
          {
            name: 'Polish',
            id: 'is_polish',
          },
          {
            name: 'Portuguese',
            id: 'is_portuguese',
          },
          {
            name: 'Professionals',
            id: 'is_professionals',
          },
          {
            name: 'Punjabi',
            id: 'is_punjabi',
          },
          {
            name: 'Russian',
            id: 'is_russian',
          },
          {
            name: 'Sign Language',
            id: 'is_sign_language',
          },
          {
            name: 'Spanish',
            id: 'is_spanish',
          },

        ],
      },

    ],
  },
  {
    name: 'NA Meetings',
    id: 'sep',
    filters: [
      {
        name: 'Day of the Week',
        id: 'days_of_week',
        filters: DAYS_WEEK,
      },
      {
        name: 'Who Can Attend',
        id: 'who_can_attend',
        options: [
          {
            name: 'Open to family and friends',
            id: 'is_open_to_family_members_and_friends',
          },
          {
            name: 'Closed - Not open to family and friends',
            id: 'is_open_to_family_members_and_friends',
          },
          {
            name: 'Men Only',
            id: 'is_men_only',
          },
          {
            name: 'Women Only',
            id: 'is_women_only',
          },
          {
            name: 'Beginners / Newcomers',
            id: 'is_open_to_newcomers',
          },
          {
            name: 'Children Welcome',
            id: 'is_child_friendly',
          },
          {
            name: 'Young People',
            id: 'is_young_people',
          },
          {
            name: 'Restricted',
            id: 'is_restricted_access',
          },
          {
            name: 'LGBT',
            id: 'is_lgbt',
          },

        ],
      },
      {
        name: 'Wheelchair Accesible',
        id: 'is_child_friendly',
        options:
          [
            {
              name: 'Yes',
              id: '',
            }
          ],

      },
      {
        name: 'Format',
        id: 'format',
        options:
          [
            {
              name: 'Step',
              id: 'is_step_study',
            },
            {
              name: 'Speaker',
              id: 'is_speaker',
            },
            {
              name: 'Literature Study',
              id: 'is_step_study',
            },
            {
              name: 'Tradition',
              id: 'is_tradition_study',
            },
            {
              name: '12 Concepts',
              id: 'is_12_concepts',
            },
            {
              name: 'Basic Concept',
              id: 'is_basic_text',
            },
            {
              name: 'Candle Light',
              id: 'is_candlelight',
            },
            {
              name: 'Discussion / Participation',
              id: 'is_discussion',
            },
            {
              name: 'IP Study',
              id: 'is_ip_study',
            },
            {
              name: 'Just for Today Study',
              id: 'is_just_for_today_study',
            },
            {
              name: 'Living Clean',
              id: 'is_living_clean',
            },
            {
              name: 'Meditation',
              id: 'is_medication',
            },
            {
              name: 'Q & A',
              id: 'is_q_and_a',
            },
            {
              name: 'Step Working Guide',
              id: 'is_step_working_guide',
            },
            {
              name: 'Topic',
              id: 'is_topic',
            },
            {
              name: 'Format Varies',
              id: 'does_format_vary',
            },

          ],

      },
      {
        name: 'Smoking Permitted',
        id: 'facility_smoking_policy',
        options:
          [
            {
              name: 'No Smoking',
              id: 'is_smoking_permitted',
            },
            {
              name: 'Smoking Permitted',
              id: 'is_smoking_permitted',
            },

          ],

      },
    ],
  },
]


