<template>
  <div class="about">
    <h1>ABOUT</h1>
    <ul>
      <li>About me point 1</li>
      <li>About me point 2</li>
      <li>About me point 3</li>
    </ul>
  </div>
</template>
