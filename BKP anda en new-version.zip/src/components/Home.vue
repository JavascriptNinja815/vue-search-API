<template >
  <div class="home container p-0">
    <template v-for="(category,index) in categories">

      <div class="modal fade" v-bind:id="'modal_'+category.id" v-if="(category.filters.length > 0)">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="pull-right">
              <button type="button" class="close" aria-label="Close" v-on:click="hideModal(category.id)">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <!-- Modal Header -->
            <!-- <div class="modal-header">
               <h4 class="modal-title">Modal Heading</h4>
               <button type="button" class="close" data-dismiss="modal">&times;</button>
             </div>-->

            <!-- Modal body -->
            <!--  <div class="modal-body">
                <div v-bind:id="'accordion_'+category.id" role="tablist" class="filters-selector"
                     aria-multiselectable="true">

                  <div class="card" v-for="(filter,index) in category.filters ">
                    <div class="card-header" role="tab" v-bind:id="'heading_'+filter.id">
                      <h5 class="mb-0">
                        <a data-toggle="collapse" v-bind:href="'#collapse_'+filter.id"
                           class="collapsed"
                           v-bind:data-parent="'#accordion_'+category.id"
                           v-bind:aria-expanded="(index==0)?'true':'false'"
                           v-bind:aria-controls="'collapse_'+filter.id">
                          {{filter.name}}
                          <icon name="angle-down" class="arrow-icon"></icon>
                        </a>

                      </h5>

                    </div>
                    <div v-bind:id="'collapse_'+filter.id" v-bind:class="['collapse', (index == 0)?'show':'']"
                         role="tabpanel"
                         v-bind:aria-labelledby="'heading_'+filter.id"
                         v-bind:data-parent="'#accordion_'+category.id">
                      <div class="card-body">
                        <b><a href="javascript:;">All</a> / <a href="javascript:;">None</a> / <a href="javascript:;">Reverse</a></b>
                        <div class="form-check" v-for="(option,index) in filter.options">
                          <label class="form-check-label">
                            <input class="form-check-input" type="checkbox" value="">
                            {{option.name}}
                          </label>
                        </div>
                      </div>
                    </div>
                  </div>


                </div>
              </div>-->

            <!-- Modal footer -->
            <!-- <div class="modal-footer">
               <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
             </div>-->

          </div>
        </div>
      </div>

    </template>
    <div class="row">
      <div class="col mb-0 mt-0 mb-sm-3 mt-sm-3 ">
        <h1><span>Search for</span> Service Providers <span>in your area</span></h1>
      </div>
    </div>
    <div class="row">
      <div class="col mb-0 mbs-3 mt-0 mts-3">
        <div id="search_box" class="container">

          <form id="main_search" role="form">

            <div class="row">
              <div class="col-sm-5 pr-sm-0">
                <div class="form-group">
                  <input type="text" class="form-control " id="name" name="name" aria-describedby="Provider Name"
                         placeholder="Provider Name">
                </div>
              </div>
              <div class="col-sm-7">

                <div class="form-group ">

                  <VueGoogleAutocomplete
                    id="place" name="place"
                    classname="form-control"
                    placeholder="Address, neighborhood, city or state"
                    v-on:placechanged=""
                    enable-geolocation="true"
                    :country="['us']"
                  >
                  </VueGoogleAutocomplete>

                </div>
              </div>

            </div>
            <div class="row" id="categories_select">
              <div
                v-bind:class="['col','col-md-3','col-6','mb-2','col-lg', (index != (categories.length-1)) ? 'pr-0 pr-lg-0' : '', (index == (categories.length/2-1)) ? 'pr-sm-3' : 'pr-sm-0',(index%4 ==3) ? 'pr-md-3' : 'pr-md-0',(index%2 ==1) ? 'pr-3 pr-sm-3' : '']"
                v-for="(category,index) in categories">
                <div v-bind:class="['select-box', 'p-2',(chosenCategories.indexOf(index) > -1)?'selected-box':''] "
                     v-on:click="toggleCategory(index)">
                  <input v-bind:id="category.id" type="checkbox" v-bind:value="index" v-model="chosenCategories"/>
                  <br class="d-none d-sm-block"/>
                  {{category.name}}
                </div>


              </div>

            </div>
            <div class="row" id="filters">
              <div class="col" v-for="(chosenCategory,index) in chosenCategories">
                <div v-bind:id="'accordion_'+chosenCategory.id" role="tablist" class="filters-selector"
                     aria-multiselectable="true">

                  <div class="card" v-for="(filter,index) in chosenCategory.filters ">
                    <div class="card-header" role="tab" v-bind:id="'heading_'+filter.id">
                      <h5 class="mb-0">
                        <a data-toggle="collapse" v-bind:href="'#collapse_'+filter.id"
                           class="collapsed"
                           v-bind:data-parent="'#accordion_'+chosenCategory.id"
                           v-bind:aria-expanded="(index==0)?'true':'false'"
                           v-bind:aria-controls="'collapse_'+filter.id">
                          {{filter.name}}
                          <icon name="angle-down" class="arrow-icon"></icon>
                        </a>

                      </h5>

                    </div>
                    <div v-bind:id="'collapse_'+filter.id" v-bind:class="['collapse', (index == 0)?'show':'']"
                         role="tabpanel"
                         v-bind:aria-labelledby="'heading_'+filter.id"
                         v-bind:data-parent="'#accordion_'+chosenCategory.id">
                      <div class="card-body">
                        <b><a href="javascript:;">All</a> / <a href="javascript:;">None</a> / <a href="javascript:;">Reverse</a></b>
                        <div class="form-check" v-for="(option,index) in filter.options">
                          <label class="form-check-label">
                            <input class="form-check-input" type="checkbox" value="">
                            {{option.name}}
                          </label>
                        </div>
                      </div>
                    </div>
                  </div>


                </div>
              </div>
            </div>
            <br/>
            <button type="submit" class="btn btn-custom btn-lg">Search</button>
          </form>
        </div>
      </div>
    </div>

    <br/>
  </div>
</template>


<script>
  import VueGoogleAutocomplete from 'vue-google-autocomplete'
  import { CATEGORIES } from '../constants.js'

  export default {
    name: 'Home',
    components: {VueGoogleAutocomplete},
    /* props: ['categories'],*/
    data () {
      return {
        address: '',
        categories: CATEGORIES,
        chosenCategories: [],
      }
    },
    mounted () {
      // To demonstrate functionality of exposed component functions
      // Here we make focus on the user input
      //  this.$refs.address.focus()
      console.log(CATEGORIES, this.categories);

    },
    methods: {
      /**
       * When the location found
       * @param {Object} addressData Data of the found location
       * @param {Object} placeResultData PlaceResult object
       * @param {String} id Input container ID
       */
      getAddressData: function (addressData, placeResultData, id) {
        this.address = addressData
      },
      /**
       * Adds or removes category if already present
       * @param integer index
       */
      toggleCategory: function (index) {
        let chosenIndex = this.chosenCategories.indexOf(index)
        if (chosenIndex > -1)
          this.chosenCategories.splice(chosenIndex, 1)
        else {
          this.chosenCategories.push(index)
          this.showFilters(index)
        }

      },
      /**
       * Opens a modal with filters, if necessary for that category
       * @param integer index index on the categories array
       */
      showFilters: function (index) {
        let category = this.categories[index]
        if (category.filters.length > 0) {
          $('#modal_' + category.id).modal('show')
        }
      },
      /**
       * Hides the modal for a category code
       * @param string code
       */
      hideModal: function (code) {
        $('#modal_' + code).modal('hide')
      },
      /**
       * Returns chosen categories as array of prototypes
       */
      chosenCategoriesObjects: function () {
        let categoriesArray = []
        for (let i = 0; i < this.chosenCategories.length; i++)
          categoriesArray.push(this.categories[this.chosenCategories[i]]);
        return categoriesArray

      }

    },

  }
</script>

<!-- Add " scoped" attribute to limit CSS to this component only -->
<style scoped>
  .home h1 {
    margin-top: 0px;
    margin-bottom: 0px;
  }

  #search_box {
    margin-top: 10px;
    background-color: white;
    border-radius: 25px;
    padding: 35px 25px;
  }

  .modal-body {
    padding-top: 0;
    font-size: 0.8rem;
    text-align: left;
  }

  @media only screen and (max-width: 575px) {
    h1 {
      font-size: 1.5rem;
    }

  }


</style>

